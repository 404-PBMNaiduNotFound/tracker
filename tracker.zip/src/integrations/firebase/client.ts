// Client-side Firebase SDK init. One import, everywhere — mirrors how
// src/integrations/supabase/client.ts used to expose a single `supabase`
// client. Import `auth`, `db`, or `getMessagingIfSupported()` from here;
// never call `initializeApp` anywhere else.
//
// NOTE: unlike the old Supabase client, these are NOT wrapped in a lazy
// Proxy. The Firebase Auth/Firestore SDKs use branded class internals that
// break when methods/getters (e.g. `auth.currentUser`, `auth.onAuthStateChanged`)
// are invoked through a Proxy receiver, so `auth`/`db` are real instances,
// initialized once on first import.
import { initializeApp, getApps, type FirebaseApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { isSupported, type Messaging } from "firebase/messaging";

function readFirebaseConfig() {
  // import.meta.env for the client build, process.env as an SSR fallback —
  // same dual-lookup pattern the old Supabase client used.
  const cfg = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || process.env.VITE_FIREBASE_API_KEY,
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || process.env.VITE_FIREBASE_AUTH_DOMAIN,
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID,
    storageBucket:
      import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || process.env.VITE_FIREBASE_STORAGE_BUCKET,
    messagingSenderId:
      import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ||
      process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
    appId: import.meta.env.VITE_FIREBASE_APP_ID || process.env.VITE_FIREBASE_APP_ID,
  };

  if (!cfg.apiKey || !cfg.projectId || !cfg.appId) {
    const missing = Object.entries(cfg)
      .filter(([k, v]) => !v && k !== "storageBucket")
      .map(([k]) => k);
    const message = `Missing Firebase environment variable(s): ${missing.join(", ")}. Set VITE_FIREBASE_* in .env — see MIGRATION_NOTES.md.`;
    console.error(`[Firebase] ${message}`);
    throw new Error(message);
  }

  return cfg;
}

function ensureApp(): FirebaseApp {
  return getApps()[0] ?? initializeApp(readFirebaseConfig());
}

const app = ensureApp();

export const auth = getAuth(app);
export const db = getFirestore(app);

export function getFirebaseApp(): FirebaseApp {
  return app;
}

/**
 * Resolves once with the current user after Firebase Auth's initial state
 * check (reading the persisted session) completes.
 */
export function waitForAuthUser() {
  return new Promise<import("firebase/auth").User | null>((resolve) => {
    const unsub = auth.onAuthStateChanged((user) => {
      unsub();
      resolve(user);
    });
  });
}

/** Firebase Messaging only works in the browser and only where the API is supported. */
export async function getMessagingIfSupported(): Promise<Messaging | null> {
  if (typeof window === "undefined") return null;
  try {
    if (!(await isSupported())) return null;
    const { getMessaging } = await import("firebase/messaging");
    return getMessaging(app);
  } catch {
    return null;
  }
}
