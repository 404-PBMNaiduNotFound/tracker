import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
} from "firebase/auth";
import { FirebaseError } from "firebase/app";
import { auth } from "@/integrations/firebase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/PasswordInput";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — A2Z DSA Tracker" },
      {
        name: "description",
        content: "Sign in to sync your Striver A2Z DSA progress across every device.",
      },
      { property: "og:title", content: "Sign in — A2Z DSA Tracker" },
      {
        property: "og:description",
        content: "Sign in to sync your Striver A2Z DSA progress across every device.",
      },
    ],
  }),
  validateSearch: (s: Record<string, unknown>) => ({ next: (s.next as string) || "/today" }),
  component: AuthPage,
});

const emailSchema = z.string().trim().email("Enter a valid email address").max(255);
const passwordSchema = z.string().min(8, "Password must be at least 8 characters").max(72);

/** Firebase's auth/* error codes -> the same friendly copy Supabase's messages used to give. */
function authErrorMessage(e: unknown): string {
  if (e instanceof FirebaseError) {
    switch (e.code) {
      case "auth/invalid-credential":
      case "auth/wrong-password":
      case "auth/user-not-found":
        return "Invalid email or password.";
      case "auth/email-already-in-use":
        return "An account with this email already exists.";
      case "auth/weak-password":
        return "Password must be at least 8 characters.";
      case "auth/popup-closed-by-user":
        return "Google sign-in was cancelled.";
      case "auth/too-many-requests":
        return "Too many attempts — please wait a moment and try again.";
      default:
        return e.message;
    }
  }
  return e instanceof Error ? e.message : "Something went wrong.";
}

function AuthPage() {
  const navigate = useNavigate();
  const { next } = useSearch({ from: "/auth" });
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [sentReset, setSentReset] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user) void navigate({ to: next, replace: true });
    });
    return () => unsub();
  }, [navigate, next]);

  const validate = () => {
    const e = emailSchema.safeParse(email);
    if (!e.success) {
      toast.error(e.error.issues[0].message);
      return null;
    }
    const p = passwordSchema.safeParse(password);
    if (!p.success) {
      toast.error(p.error.issues[0].message);
      return null;
    }
    return { email: e.data, password: p.data };
  };

  async function signIn() {
    const v = validate();
    if (!v) return;
    setBusy(true);
    try {
      await signInWithEmailAndPassword(auth, v.email, v.password);
      void navigate({ to: next, replace: true });
    } catch (e) {
      toast.error(authErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function signUp() {
    const v = validate();
    if (!v) return;
    setBusy(true);
    try {
      await createUserWithEmailAndPassword(auth, v.email, v.password);
      // Firebase signs the user in immediately on account creation (no
      // email-confirmation gate by default), matching the old
      // "no confirmation required" path from Supabase's signUp response.
      void navigate({ to: next, replace: true });
    } catch (e) {
      toast.error(authErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    try {
      const provider = new GoogleAuthProvider();
      try {
        await signInWithPopup(auth, provider);
        void navigate({ to: next, replace: true });
      } catch (e) {
        // Popups are blocked on some mobile browsers/in-app webviews — fall
        // back to a full-page redirect; the redirect result resolves via the
        // onAuthStateChanged listener above once the browser returns here.
        if (e instanceof FirebaseError && e.code === "auth/popup-blocked") {
          await signInWithRedirect(auth, provider);
          return;
        }
        throw e;
      }
    } catch (e) {
      toast.error("Google sign-in failed", { description: authErrorMessage(e) });
    }
  }

  async function forgot() {
    const e = emailSchema.safeParse(email);
    if (!e.success) return toast.error("Enter your email first");
    try {
      await sendPasswordResetEmail(auth, e.data, {
        url: `${window.location.origin}/reset-password`,
        handleCodeInApp: true,
      });
      setSentReset(true);
      toast.success("Reset link sent — check your inbox.");
    } catch (err) {
      toast.error(authErrorMessage(err));
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <Link
          to="/"
          className="mb-6 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          Back to home
        </Link>
      <Card className="w-full border-border bg-card">
        <CardHeader>
          <CardTitle className="text-2xl">A2Z DSA Tracker</CardTitle>
          <CardDescription>
            474 problems · 18 sections · 120 days. Sign in to sync progress across devices.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <Button variant="secondary" className="w-full" onClick={() => void google()}>
            Continue with Google
          </Button>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="h-px flex-1 bg-border" /> or use email{" "}
            <span className="h-px flex-1 bg-border" />
          </div>
          <Tabs defaultValue="signin">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Log in</TabsTrigger>
              <TabsTrigger value="signup">Sign up</TabsTrigger>
            </TabsList>
            <div className="mt-4 space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">Password</Label>
                <PasswordInput
                  id="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>
            <TabsContent value="signin" className="mt-4 space-y-3">
              <Button className="w-full" disabled={busy} onClick={() => void signIn()}>
                {busy && <Loader2 className="mr-2 size-4 animate-spin" />} Log in
              </Button>
              <button
                type="button"
                onClick={() => void forgot()}
                className="w-full text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground"
              >
                {sentReset ? "Reset link sent" : "Forgot password?"}
              </button>
            </TabsContent>
            <TabsContent value="signup" className="mt-4">
              <Button className="w-full" disabled={busy} onClick={() => void signUp()}>
                {busy && <Loader2 className="mr-2 size-4 animate-spin" />} Create account
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      </div>
    </main>
  );
}
