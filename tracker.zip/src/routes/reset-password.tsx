import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { confirmPasswordReset, verifyPasswordResetCode } from "firebase/auth";
import { auth } from "@/integrations/firebase/client";
import { Button } from "@/components/ui/button";
import { PasswordInput } from "@/components/PasswordInput";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Reset password — A2Z DSA Tracker" },
      { name: "description", content: "Choose a new password for your A2Z DSA Tracker account." },
      { property: "og:title", content: "Reset password — A2Z DSA Tracker" },
      { property: "og:description", content: "Choose a new password for your tracker account." },
    ],
  }),
  // Firebase's password reset link lands here with ?mode=resetPassword&oobCode=...
  validateSearch: (s: Record<string, unknown>) => ({
    oobCode: (s.oobCode as string) || "",
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const { oobCode } = Route.useSearch();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(true);
  const [validCode, setValidCode] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!oobCode) {
      setChecking(false);
      return;
    }
    verifyPasswordResetCode(auth, oobCode)
      .then(() => setValidCode(true))
      .catch(() => setValidCode(false))
      .finally(() => setChecking(false));
  }, [oobCode]);

  async function submit() {
    if (password.length < 8) return toast.error("Password must be at least 8 characters");
    setBusy(true);
    try {
      await confirmPasswordReset(auth, oobCode, password);
      toast.success("Password updated");
      void navigate({ to: "/auth", search: { next: "/today" } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not reset your password.");
    } finally {
      setBusy(false);
    }
  }

  if (checking) {
    return (
      <main className="flex min-h-screen items-center justify-center px-4">
        <Skeleton className="h-64 w-full max-w-md" />
      </main>
    );
  }

  if (!oobCode || !validCode) {
    return (
      <main className="flex min-h-screen items-center justify-center px-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>This reset link is invalid or expired</CardTitle>
            <CardDescription>
              Request a new reset link from the sign-in page and try again.
            </CardDescription>
          </CardHeader>
        </Card>
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Set a new password</CardTitle>
          <CardDescription>Open this page from the reset link in your email.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="np">New password</Label>
            <PasswordInput
              id="np"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button className="w-full" disabled={busy} onClick={() => void submit()}>
            Update password
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}
